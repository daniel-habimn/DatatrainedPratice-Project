/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MImplementation;

import Mdao.ClientDao;
import Mmodel.Client;
import Mservice.ClientService;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author Admin
 */
public class ClientImplementation extends UnicastRemoteObject implements ClientService{

    public ClientImplementation()throws RemoteException{
        super();
    }
    
    public ClientDao dao = new ClientDao();

    @Override
    public String saveclient(Client client) throws RemoteException {
        return dao.saveclient(client);
    }

    @Override
    public String updateclient(Client client) throws RemoteException {
        return dao.updateclient(client);
    }

    @Override
    public String deleteclient(Client client) throws RemoteException {
        return dao.deleteclient(client);   
    }

    @Override
    public List<Client> getClients() throws RemoteException {
    return dao.allClients();    
    }

    @Override
    public List<Client> Login(String clientname, String password) throws RemoteException {
        return dao.Login(clientname, password);
    }

    
}
