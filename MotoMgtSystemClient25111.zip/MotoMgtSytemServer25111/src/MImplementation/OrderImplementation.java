/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MImplementation;

import Mdao.OrderDao;
import Mmodel.Order;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import Mservice.OrderService;

/**
 *
 * @author Admin
 */
public class OrderImplementation extends UnicastRemoteObject implements OrderService{

    public OrderImplementation() throws RemoteException{
        super();
    }
    
    public OrderDao dao = new OrderDao();

    @Override
    public String saveorder(Order order) throws RemoteException {
        return dao.saveorder(order);
    }

    @Override
    public String updateorder(Order order) throws RemoteException {
        return dao.updateorder(order);    }

    @Override
    public String deleteorder(Order order) throws RemoteException {
        return dao.deleteorder(order);    }

    @Override
    public List<Order> getallorders() throws RemoteException {
        return dao.allOrders();    }

    @Override
    public Order getorder(Order order) throws RemoteException {
        return dao.getorders(order);    }


    
    
}
