/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mdao;

import Mmodel.Order;
import java.util.Collections;
import java.util.List;
import org.hibernate.*;


public class OrderDao {

    public String saveorder(Order order) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();

        ss.save(order);
        tr.commit();

        ss.close();
        return "saved";

    }

    public String updateorder(Order order) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();

        ss.update(order);
        tr.commit();

        ss.close();
        return "updated";

    }

    public String deleteorder(Order order) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();

        ss.delete(order);
        tr.commit();

        ss.close();
        return "deleted";

    }

    public List<Order> allOrders() {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Order> orders = ss.createQuery("select pur from Orders pur").list();
        ss.close();
        return orders;

    }

    public Order getorders(Order orders) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Order pur = (Order) ss.get(Order.class, orders.getOrderId());
        ss.close();
        return pur;

    }
    
}
