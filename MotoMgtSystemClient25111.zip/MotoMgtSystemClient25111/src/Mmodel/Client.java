/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mmodel;

import java.io.Serializable;



/**
 *
 * @author Admin
 */
public class Client implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private Integer client_id;

    private String username;

    private String password;

    public Client() {
    }

    public Client(Integer client_id, String username, String password) {
        this.client_id = client_id;
        this.username = username;
        this.password = password;
    }

    public Integer getClient_id() {
        return client_id;
    }

    public void setClient_id(Integer client_id) {
        this.client_id = client_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    
    
}
