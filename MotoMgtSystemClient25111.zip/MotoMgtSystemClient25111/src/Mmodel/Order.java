/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mmodel;

import java.io.Serializable;
import java.util.Date;


public class Order implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private Integer orderId;
    private Date orderDate;
    private Integer quantity;
    private Client client;
    private Motto motto;

    public Order() {
    }

    public Order(Integer orderId, Date orderDate, Integer quantity, Client client, Motto motto) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.quantity = quantity;
        this.client = client;
        this.motto = motto;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Motto getMotto() {
        return motto;
    }

    public void setMotto(Motto motto) {
        this.motto = motto;
    }
    
    


}
