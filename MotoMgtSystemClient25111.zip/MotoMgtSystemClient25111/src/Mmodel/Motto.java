/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mmodel;

import java.io.Serializable;



public class Motto implements Serializable{
    private static final long serialVersionUID = 1L;
    

    private Integer mottoId;
    private String mottoMake;
    private String mottoModel;
    private Integer price;
    private String supplier;

    public Motto() {
    }

    public Motto(Integer mottoId, String mottoMake, String mottoModel, Integer price, String supplier) {
        this.mottoId = mottoId;
        this.mottoMake = mottoMake;
        this.mottoModel = mottoModel;
        this.price = price;
        this.supplier = supplier;
    }

    public Integer getMottoId() {
        return mottoId;
    }

    public void setMottoId(Integer mottoId) {
        this.mottoId = mottoId;
    }

    public String getMottoMake() {
        return mottoMake;
    }

    public void setMottoMake(String mottoMake) {
        this.mottoMake = mottoMake;
    }

    public String getMottoModel() {
        return mottoModel;
    }

    public void setMottoModel(String mottoModel) {
        this.mottoModel = mottoModel;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    @Override
    public String toString() {
        return "MOTTO ID: " + mottoId + ", MOTTO MAKE :" + mottoMake + "MOTTO MODEL: " + mottoModel + ", PRICE:" + price+"SUPPLIER: " +supplier +"";
    }
    
}
