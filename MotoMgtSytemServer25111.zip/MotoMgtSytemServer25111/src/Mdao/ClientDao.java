/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mdao;


import Mmodel.Client;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Admin
 */
public class ClientDao {
    
    public String saveclient(Client client){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.save(client);
        tr.commit();
        
        ss.close();
        return "saved";
        
    }
    public String updateclient(Client client){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.update(client);
        tr.commit();
        
        ss.close();
        return "updated";
        
    }
    public String deleteclient(Client client){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.delete(client);
        tr.commit();
        
        ss.close();
        return "delete";
        
    }
    public List<Client> allClients(){
     
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Client> clients = ss.createQuery("select us from Client us").list();
        ss.close();
        return clients;
        
    }
    public List<Client> Login(String clientname, String password){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Client> clientlist = null;
        try {
            
            Query query = ss.createQuery("select client from Client client where client.clientname = :clientname and client.password = :password");
            query.setParameter("clientname", clientname);
            query.setParameter("password", password);
            
            clientlist = query.list();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            ss.close();
        }
       return clientlist;
    }
}
