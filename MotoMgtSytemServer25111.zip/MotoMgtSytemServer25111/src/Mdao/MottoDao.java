/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mdao;


import Mmodel.Motto;
import Mmodel.Order;
import java.util.Collections;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Admin
 */
public class MottoDao {
    
    public String savemotto(Motto motto){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.save(motto);
        tr.commit();
        
        ss.close();
        return "saved";
        
    }
    public String updatemotto(Motto motto){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.update(motto);
        tr.commit();
        
        ss.close();
        return "updated";
        
    }
    public String deletemotto(Motto motto){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.delete(motto);
        tr.commit();
        
        ss.close();
        return "deleted";
        
    }
    public List<Motto> allmottos(){
     
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Motto> mottos = ss.createQuery("select ca from Motto ca").list();
        ss.close();
        return mottos;
        
    }
    public Motto getmotto(Motto motto){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Motto pro = (Motto)ss.get(Motto.class, motto.getMottoId());
        ss.close();
        return pro;
        
    }
    
    public List<Motto> retrieveTableData(){
        List<Motto> tableData;
        try{
            Session ss = HibernateUtil.getSessionFactory().openSession();
            Query query = ss.createQuery("FROM motto");
            tableData = query.list();
        } catch (Exception e) {
            e.printStackTrace();
            tableData = Collections.emptyList();
        }
        return tableData;
    }
}
