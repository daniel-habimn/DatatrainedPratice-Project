/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MImplementation;


import Mdao.MottoDao;
import Mmodel.Motto;
import Mservice.MottoService;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;



public class MottoImplementation extends UnicastRemoteObject implements MottoService{

    public MottoImplementation()throws RemoteException{
        super();
    }
    
    public MottoDao dao = new MottoDao();

    @Override
    public String saveMotto(Motto motto) throws RemoteException {
        return dao.savemotto(motto);
    }

    @Override
    public String updateMotto(Motto motto) throws RemoteException {
        return dao.updatemotto(motto);    
    }

    @Override
    public String deleteMotto(Motto motto) throws RemoteException {
        return dao.deletemotto(motto);    
    }

    @Override
    public List<Motto> getMottos() throws RemoteException {
        return dao.allmottos();    
    }

    @Override
    public Motto getMotto(Motto motto) throws RemoteException {
        return dao.getmotto(motto);    }
    
    @Override
    public List<Motto> retrieveTableData() throws RemoteException {
        return dao.retrieveTableData();   }
    
}
