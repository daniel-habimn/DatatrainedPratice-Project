/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mservice;

import Mmodel.Client;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 *
 * @author Admin
 */
public interface ClientService extends Remote{
    public String saveclient(Client client) throws RemoteException;
    public String updateclient(Client client) throws RemoteException;
    public String deleteclient(Client client) throws RemoteException;
    public List<Client> getClients() throws RemoteException;
    public List<Client> Login(String clientname, String password) throws RemoteException;
}
