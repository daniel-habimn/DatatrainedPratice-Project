/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mservice;

import Mmodel.Motto;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 *
 * @author Admin
 */
public interface MottoService extends Remote{
    public String saveMotto(Motto motto) throws RemoteException;
    public String updateMotto(Motto motto) throws RemoteException;
    public String deleteMotto(Motto motto) throws RemoteException;
    public List<Motto> getMottos() throws RemoteException;
    public Motto getMotto (Motto motto) throws RemoteException;
    public List<Motto> retrieveTableData() throws RemoteException;
}