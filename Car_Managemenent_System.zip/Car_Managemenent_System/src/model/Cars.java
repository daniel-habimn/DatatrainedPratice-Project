
package model;

/**
 *
 * @author user
 */
public class Cars {
 
    private String car_id;
    private String car_name;
    private String model;
    private Double price;
    private String fuel_type;

    public String getCar_id() {
        return car_id;
    }

    public void setCar_id(String car_id) {
        this.car_id = car_id;
    }

    public String getCar_name() {
        return car_name;
    }

    public void setCar_name(String car_name) {
        this.car_name = car_name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getFuel_type() {
        return fuel_type;
    }

    public void setFuel_type(String fuel_type) {
        this.fuel_type = fuel_type;
    }

    public Cars(String car_id, String car_name, String model, Double price, String fuel_type) {
        this.car_id = car_id;
        this.car_name = car_name;
        this.model = model;
        this.price = price;
        this.fuel_type = fuel_type;
    }

    public Cars() {
    }

    
    
}
