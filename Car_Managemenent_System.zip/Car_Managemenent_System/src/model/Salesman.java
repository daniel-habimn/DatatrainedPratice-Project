
package model;

/**
 *
 * @author user
 */
public class Salesman {
    
    private String salesman_id;
    private String salesman_name;
    private String salesman_email;
    private String salesman_address;
    private String salesman_phone;

    public Salesman() {
    }

    public Salesman(String salesman_id, String salesman_name, String salesman_email, String salesman_address, String salesman_phone) {
        this.salesman_id = salesman_id;
        this.salesman_name = salesman_name;
        this.salesman_email = salesman_email;
        this.salesman_address = salesman_address;
        this.salesman_phone = salesman_phone;
    }

    public String getSalesman_id() {
        return salesman_id;
    }

    public void setSalesman_id(String salesman_id) {
        this.salesman_id = salesman_id;
    }

    public String getSalesman_name() {
        return salesman_name;
    }

    public void setSalesman_name(String salesman_name) {
        this.salesman_name = salesman_name;
    }

    public String getSalesman_email() {
        return salesman_email;
    }

    public void setSalesman_email(String salesman_email) {
        this.salesman_email = salesman_email;
    }

    public String getSalesman_address() {
        return salesman_address;
    }

    public void setSalesman_address(String salesman_address) {
        this.salesman_address = salesman_address;
    }

    public String getSalesman_phone() {
        return salesman_phone;
    }

    public void setSalesman_phone(String salesman_phone) {
        this.salesman_phone = salesman_phone;
    }
  
    
}
