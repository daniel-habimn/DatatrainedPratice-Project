
package model;

/**
 *
 * @author user
 */
public class Sale {
    
    private String sales_id;
    private String salesman_id;
    private String car_id;
    private String sale_date;
    private Double amount;
    private String client_id;

    public Sale() {
    }

    public Sale(String sales_id, String salesman_id, String car_id, String sale_date, Double amount, String client_id) {
        this.sales_id = sales_id;
        this.salesman_id = salesman_id;
        this.car_id = car_id;
        this.sale_date = sale_date;
        this.amount = amount;
        this.client_id = client_id;
    }

    public String getSales_id() {
        return sales_id;
    }

    public void setSales_id(String sales_id) {
        this.sales_id = sales_id;
    }

    public String getSalesman_id() {
        return salesman_id;
    }

    public void setSalesman_id(String salesman_id) {
        this.salesman_id = salesman_id;
    }

    public String getCar_id() {
        return car_id;
    }

    public void setCar_id(String car_id) {
        this.car_id = car_id;
    }

    public String getSale_date() {
        return sale_date;
    }

    public void setSale_date(String sale_date) {
        this.sale_date = sale_date;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }
    
    
}
