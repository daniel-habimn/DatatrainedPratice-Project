
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import model.Cars;
import model.Client;

/**
 *
 * @author user
 */
public class ClientDao {
    
    private String jdbcUrl = "jdbc:mysql://localhost/car_management_system_db";
     private String user = "root";
     Scanner input = new Scanner(System.in);
    public Integer  registerClient(Client theClient){
        //surround with try and catch
        try{
            // create connection
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            // Prepare Statements
            String sql = "INSERT INTO client (client_id,client_name,client_email,client_address,client_phone) VALUES(?,?,?,?,?)";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, theClient.getClient_id());
            pst.setString(2, theClient.getClient_name());
            pst.setString(3, theClient.getClient_email());
            pst.setString(4, theClient.getClient_address());
            pst.setString(5, theClient.getClient_phone());
            // execute 
            int rowAffected = pst.executeUpdate();
            // close connection
            connection.close();
            return rowAffected;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
    public ResultSet Viewclient() {
        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM client";
            PreparedStatement pst = connection.prepareStatement(sql);
            
            ResultSet results = pst.executeQuery();
            //connection.close();
            return results;
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public Integer DeleteClient(int theId) {
        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            String sql = "DELETE FROM client WHERE client_id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, theId);
            Integer rowsAffected = pst.executeUpdate();
            connection.close();
            return rowsAffected;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

public Integer UpdateClient(Client theClient) {
        //surround with try and catch
        try {
            // create connection
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            // Prepare Statements
            String sql = "UPDATE client SET client_name=? ,client_email=? ,client_address=? ,client_phone=? WHERE client_id=?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(5, theClient.getClient_id());
            pst.setString(1, theClient.getClient_name());
            pst.setString(2, theClient.getClient_email());
            pst.setString(3, theClient.getClient_address());
            pst.setString(4, theClient.getClient_phone());
            // execute 
            int rowAffected = pst.executeUpdate();
            // close connection
            connection.close();
            return rowAffected;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

public ResultSet searchClient(String SearchClientTxt) {
    
        try {
            //Connection Start
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            //Query
            
            String sql = "SELECT * FROM client WHERE client_id LIKE ?";
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            
            pst.setString(1, "%" + SearchClientTxt + "%");
            //Resultset
            
            ResultSet results = pst.executeQuery();
            //connection.close();
            return results;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

}
