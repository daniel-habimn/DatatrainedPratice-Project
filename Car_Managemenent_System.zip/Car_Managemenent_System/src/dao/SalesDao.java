package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import model.Sale;

/**
 *
 * @author user
 */
public class SalesDao {

    private String jdbcUrl = "jdbc:mysql://localhost/car_management_system_db";
    private String user = "root";
    Scanner input = new Scanner(System.in);

    public Integer registerSale(Sale theSale) {
        //surround with try and catch
        try {
            // create connection
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            // Prepare Statements
            
            String sql = "INSERT INTO sales (sales_id,salesman_id,car_id,sale_date,amount,client_id) VALUES(?,?,?,?,?,?)";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, theSale.getSales_id());
            pst.setString(2, theSale.getSalesman_id());
            pst.setString(3, theSale.getCar_id());
            pst.setString(4, theSale.getSale_date());
            pst.setDouble(5, theSale.getAmount());
            pst.setString(6, theSale.getClient_id());
            
            // execute 
            Integer rowAffected = pst.executeUpdate();
            
            // close connection
            
            connection.close();
            return rowAffected;
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ResultSet allSales() {
        
        try {
            
            //Connection
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            //query
            
            String sql = "SELECT * FROM sales";
            
            //Prepared_statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet results = pst.executeQuery();
            
            //connection.close();
            
            return results;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public Integer DeleteSales(int theId) {
        try {
            
            //Connection
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            //Query
            
            String sql = "DELETE FROM sales WHERE sales_id = ?";
            
            //statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, theId);
            Integer rowsAffected = pst.executeUpdate();
            
            //close connection
            
            connection.close();
            return rowsAffected;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public Integer UpdateSale(Sale theSale) {
        //surround with try and catch
        try {
            // create connection
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            // Query
            
            String sql = "UPDATE sales SET salesman_id=? ,car_id=? ,sale_date=? ,amount=?,client_id=? WHERE sales_id=?";
            
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(6, theSale.getSales_id());
            pst.setString(1, theSale.getSalesman_id());
            pst.setString(2, theSale.getCar_id());
            pst.setString(3, theSale.getSale_date());
            pst.setDouble(4, theSale.getAmount());
            pst.setString(5, theSale.getClient_id());
            
            // execute 
            
            int rowAffected = pst.executeUpdate();
            
            // close connection
            
            connection.close();
            return rowAffected;
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public ResultSet searchSales(String searchsalesTxt) {
        try {
            //Connection
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            //Query
            
            String sql = "SELECT * FROM sales WHERE sales_id LIKE ?";
            
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, "%" + searchsalesTxt + "%");
            ResultSet results = pst.executeQuery();
            
            //connection.close();
            return results;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
