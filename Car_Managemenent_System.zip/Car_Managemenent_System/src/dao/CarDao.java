package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import model.Cars;

/**
 *
 * @author user
 */
public class CarDao {

    private String jdbcUrl = "jdbc:mysql://localhost/car_management_system_db";
    private String user = "root";
    Scanner input = new Scanner(System.in);

    public Integer registerCars(Cars theCars) {
        //surround with try and catch
        try {
            // create connection
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            // Query
            String sql = "INSERT INTO cars (car_id,car_name,model,price,fuel_type) VALUES(?,?,?,?,?)";
            
            //Statement 
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, theCars.getCar_id());
            pst.setString(2, theCars.getCar_name());
            pst.setString(3, theCars.getModel());
            pst.setDouble(4, theCars.getPrice());
            pst.setString(5, theCars.getFuel_type());
            
            // Execute the Statement
            int rowAffected = pst.executeUpdate();
            
            // close connection
            
            connection.close();
            return rowAffected;
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ResultSet Viewcars() {
        try {
            //Connection start
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            //Query
            
            String sql = "SELECT * FROM cars";
            
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet results = pst.executeQuery();
            
            //connection.close();
            return results;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    

    public Integer DeleteCars(int theId) {
        try {
            
            //Connection start
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            //Query
            
            String sql = "DELETE FROM cars WHERE car_id = ?";
            
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, theId);
            Integer rowsAffected = pst.executeUpdate();
            // close connection
            
            connection.close();
            return rowsAffected;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public Integer UpdateCars(Cars theCars) {
        
        //surround with try and catch || start by try and catch
        
        try {
            
            // create connection
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            // Query
            
            String sql = "UPDATE cars SET car_name=? ,model=? ,price=? ,fuel_type=? WHERE car_id=?";
            
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(5, theCars.getCar_id());
            pst.setString(1, theCars.getCar_name());
            pst.setString(2, theCars.getModel());
            pst.setDouble(3, theCars.getPrice());
            pst.setString(4, theCars.getFuel_type());
            
            // Execute 
            int rowAffected = pst.executeUpdate();
            
            // Close connection
            
            connection.close();
            return rowAffected;
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ResultSet searchCar(String searchTxt) {
        try {
            //Connection start
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            //Query
            
            String sql = "SELECT * FROM cars WHERE car_name LIKE ?";
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, "%" + searchTxt + "%");
            ResultSet results = pst.executeQuery();
            
            //connection.close();
            return results;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
}
