
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import model.Salesman;

/**
 *
 * @author user
 */
public class SalesmanDao {
    
    private String jdbcUrl = "jdbc:mysql://localhost/car_management_system_db";
     private String user = "root";
     Scanner input = new Scanner(System.in);
    public Integer  registerSalesman(Salesman theSalesman){
        //surround with try and catch
        try{
            // create connection
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            // Prepare Statements
            String sql = "INSERT INTO salesman (salesman_id,salesman_name,salesman_email,salesman_address,salesman_phone) VALUES(?,?,?,?,?)";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, theSalesman.getSalesman_id());
            pst.setString(2, theSalesman.getSalesman_name());
            pst.setString(3, theSalesman.getSalesman_email());
            pst.setString(4, theSalesman.getSalesman_address());
            pst.setString(5, theSalesman.getSalesman_phone());
            // execute 
            int rowAffected = pst.executeUpdate();
            // close connection
            connection.close();
            return rowAffected;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
    
    public ResultSet ViewSalesman() {
        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM salesman";
            PreparedStatement pst = connection.prepareStatement(sql);
            
            ResultSet results = pst.executeQuery();
            //connection.close();
            return results;
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public Integer DeleteSalesman(int theId) {
        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            String sql = "DELETE FROM salesman WHERE salesman_id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, theId);
            Integer rowsAffected = pst.executeUpdate();
            connection.close();
            return rowsAffected;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public Integer UpdateSalesman(Salesman theSalesman) {
        //surround with try and catch
        try {
            // create connection
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            // Prepare Statements
            String sql = "UPDATE salesman SET salesman_name=? ,salesman_email=? ,salesman_address=? ,salesman_phone=? WHERE salesman_id=?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(5, theSalesman.getSalesman_id());
            pst.setString(1, theSalesman.getSalesman_name());
            pst.setString(2, theSalesman.getSalesman_email());
            pst.setString(3, theSalesman.getSalesman_address());
            pst.setString(4, theSalesman.getSalesman_phone());
            // execute 
            int rowAffected = pst.executeUpdate();
            // close connection
            connection.close();
            return rowAffected;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public ResultSet SearchSalesman(String salesmanTxt) {
        try {
            //Connection
            
            Connection connection = DriverManager.getConnection(jdbcUrl, user, "");
            Statement statement = connection.createStatement();
            
            //Query
            
            String sql = "SELECT * FROM salesman WHERE salesman_name LIKE ?";
            //Statement
            
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, "%" + salesmanTxt + "%");
            //Resultset
            
            ResultSet results = pst.executeQuery();
            //connection.close();
            return results;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
}
